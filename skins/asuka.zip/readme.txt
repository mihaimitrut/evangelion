Asuka Strikes!

I know the title is _lame_ but I couldn't think of anything else.  Forgive me onegai!

Let me reiterate something.  I hate doing playlist editors.  But this one turned out okay.

I feel like I'm stuck in a rut in my skin style.  Perhaps in my next one I will do something radically different.  Saa, such is life.

Otherwise, I wanted the buttons and so forth to match the coloring style of Yoshiyuki Sadamoto-sensei.  It worked out moderately well, but much better than the first time I tried (as in my first Asuka skin).

I pretty much made this skin because I was SO happy to get the "der mond" artbook.

Firefly

Shiawase Anime Skins
http://perryandtsua.com/Skins/

Resident of the Happy Hentai House